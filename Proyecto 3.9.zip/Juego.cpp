#include "Juego.h"
#include "Estrategia.h"

Juego::Juego(int filas, int columnas, Jugador* j1, Jugador* j2, bool** area) {
    tablero = new Tablero(filas, columnas);
    tablero->configurarAreaIrregular(area);
    jugador1 = j1;
    jugador2 = j2;
    jugadorActual = jugador1;
    estrategia = nullptr; // Inicialmente sin estrategia
}

Juego::Juego()
{
    tablero = nullptr;
    jugador1 = nullptr;
    jugador2 = nullptr;
    jugadorActual = jugador1;
    estrategia = nullptr; // Inicialmente sin estrategia
}

Juego::~Juego() {
    delete tablero;
    delete estrategia; // Aseguramos liberar la estrategia
}

void Juego::cambiarTurno() {
    if (jugadorActual == jugador1)
        jugadorActual = jugador2;
    else
        jugadorActual = jugador1;
}

bool Juego::esMovimientoValido(int x1, int y1, int x2, int y2) {
    if ((x1 == x2 && abs(y1 - y2) == 1) || (y1 == y2 && abs(x1 - x2) == 1)) {
        return tablero->esAreaValida(x1, y1) && tablero->esAreaValida(x2, y2) && !tablero->lineaExiste(x1, y1, x2, y2); //Camino para entrar en el metodo con error
    }
    return false;
}

void Juego::iniciarJuego() {
    // placeholder
}

bool Juego::hacerMovimiento(int x1, int y1, int x2, int y2) {
    if (esMovimientoValido(x1, y1, x2, y2)) {
        if (tablero->agregarLinea(x1, y1, x2, y2)) {
            // Verificar si se ha formado un cuadrado
            jugadorActual->setUltimaJugada(x1, y1, x2, y2);
            if (verificarCuadrados(x1, y1, x2, y2)) {
                // Si se form� un cuadrado, no cambiar el turno
                return true;
            }
            else {
                // Si no se form� un cuadrado, cambiar el turno
                cambiarTurno();
                return true;
            }
        }
    }
    return false;
}

bool Juego::verificarCuadrados(int x1, int y1, int x2, int y2) {
    bool seFormoCuadrado = false;

    // Verificar todas las posiciones alrededor de la l�nea agregada
    for (int dx = -1; dx <= 0; ++dx) {
        for (int dy = -1; dy <= 0; ++dy) {
            int nx = x1 + dx;
            int ny = y1 + dy;
            if (nx >= 0 && ny >= 0 && nx < tablero->getFilas() - 1 && ny < tablero->getColumnas() - 1 && esCuadradoCompleto(nx, ny)) {
                // Si se form� un cuadrado, actualizar el tablero y la puntuaci�n
                int centroX = nx * 2 + 1;
                int centroY = ny * 2 + 1;
                if (*tablero->obtenerBoard()[centroX][centroY] == ' ') {
                    *tablero->obtenerBoard()[centroX][centroY] = jugadorActual->getNombre()[0];
                    jugadorActual->incrementarPuntuacion(1);
                    seFormoCuadrado = true;
                }
            }
        }
    }

    return seFormoCuadrado;
}


bool Juego::esCuadradoCompleto(int x, int y) {
    if (x < 0 || y < 0 || x >= tablero->getFilas() - 1 || y >= tablero->getColumnas() - 1) {
        return false;
    }
    return *tablero->obtenerBoard()[x * 2][y * 2] == '+' &&
        *tablero->obtenerBoard()[x * 2][(y * 2) + 2] == '+' &&
        *tablero->obtenerBoard()[(x * 2) + 2][y * 2] == '+' &&
        *tablero->obtenerBoard()[(x * 2) + 2][(y * 2) + 2] == '+' &&
        *tablero->obtenerBoard()[x * 2][(y * 2) + 1] != ' ' &&
        *tablero->obtenerBoard()[(x * 2) + 1][y * 2] != ' ' &&
        *tablero->obtenerBoard()[(x * 2) + 1][(y * 2) + 2] != ' ' &&
        *tablero->obtenerBoard()[(x * 2) + 2][(y * 2) + 1] != ' ';
}


Tablero* Juego::obtenerTablero() const {
    return tablero;
}

Jugador* Juego::obtenerJugadorActual() const {
    return jugadorActual;
}

Jugador* Juego::obtenerJugador1() const {
    return jugador1;
}

Jugador* Juego::obtenerJugador2() const {
    return jugador2;
}


bool Juego::esFinDelJuego() const {
    for (int i = 0; i < tablero->getFilas() * 2 - 1; ++i) {
        for (int j = 0; j < tablero->getColumnas() * 2 - 1; ++j) {
            if (*tablero->obtenerBoard()[i][j] == ' ') {
                return false;
            }
        }
    }
    return true;
}

Jugador* Juego::determinarGanador() const {
    if (jugador1->getPuntuacionActual() > jugador2->getPuntuacionActual()) {
        return jugador1;
    }
    else if (jugador2->getPuntuacionActual() > jugador1->getPuntuacionActual()) {
        return jugador2;
    }
    else {
        return nullptr; // Empate
    }
}


void Juego::cambiarEstrategia(Estrategia* nuevaEstrategia) {
    estrategia = nuevaEstrategia;
}

void Juego::realizarMovimientoAI() {
    estrategia->realizarMovimiento(this);
}

bool Juego::dejaCasillaDisponibleParaOponente(int x1, int y1, int x2, int y2) {
    Tablero* tablero = obtenerTablero();

    

    // Simular el movimiento
    tablero->agregarLinea(x1, y1, x2, y2);

    // Verificar si alguna casilla alrededor de (x1, y1) o (x2, y2) queda a un movimiento de completarse
    bool resultado = false;

    // Verificar las casillas alrededor de (x1, y1)
    if (tablero->posicionValida(x1, y1)) resultado |= tablero->dejaCasillaCasiCompleta(x1, y1);
    if (tablero->posicionValida(x1 - 1, y1)) resultado |= tablero->dejaCasillaCasiCompleta(x1 - 1, y1);
    if (tablero->posicionValida(x1, y1 - 1)) resultado |= tablero->dejaCasillaCasiCompleta(x1, y1 - 1);
    if (tablero->posicionValida(x1 - 1, y1 - 1)) resultado |= tablero->dejaCasillaCasiCompleta(x1 - 1, y1 - 1);

    // Verificar las casillas alrededor de (x2, y2)
    if (tablero->posicionValida(x2, y2)) resultado |= tablero->dejaCasillaCasiCompleta(x2, y2);
    if (tablero->posicionValida(x2 - 1, y2)) resultado |= tablero->dejaCasillaCasiCompleta(x2 - 1, y2);
    if (tablero->posicionValida(x2, y2 - 1)) resultado |= tablero->dejaCasillaCasiCompleta(x2, y2 - 1);
    if (tablero->posicionValida(x2 - 1, y2 - 1)) resultado |= tablero->dejaCasillaCasiCompleta(x2 - 1, y2 - 1);

    // Revertir el movimiento simulado
    tablero->removerLinea(x1, y1, x2, y2);

    return resultado;
}


bool Juego::dejaCasillaDisponibleParaJugador(int x1, int y1, int x2, int y2) {
    Tablero* tablero = obtenerTablero();

    

    tablero->agregarLinea(x1, y1, x2, y2);

    // Verificar si alguna casilla alrededor de (x1, y1) o (x2, y2) queda completa
    bool resultado = tablero->dejaCasillaCompleta(x1, y1, x2, y2);

    // Revertir el movimiento simulado
    tablero->removerLinea(x1, y1, x2, y2);

    return resultado;
}

void Juego::guardarEstado(const string& filename) {
    std::ofstream file(filename, std::ios::binary);
    if (!file.is_open()) {
        cerr << "Error: No se pudo abrir el archivo para escribir." << endl;
        return;
    }
    // Guardar los atributos primitivos de la clase Juego
    file.write(reinterpret_cast<const char*>(this), sizeof(*this));
    file.close();

    std::cout << "Estado del juego guardado exitosamente." << std::endl;
}

// Deserializar el estado del juego desde un formato binario
Juego* Juego::cargarEstado(const std::string& filename) {
    ifstream file(filename, std::ios::binary);
    if (!file.is_open()) {
        cerr << "Error: No se pudo abrir el archivo para leer." << endl;
        return nullptr;
    }
    Juego* juego = new Juego();
    file.read(reinterpret_cast<char*>(juego), sizeof(*juego));
    file.close();
    std::cout << "Estado del juego cargado exitosamente." << std::endl;
    return juego;
}