#include "EstrategiaPeriferica.h"

void EstrategiaPeriferica::realizarMovimiento(Juego* juego) {
    Tablero* tablero = juego->obtenerTablero();
    int filas = tablero->getFilas();
    int columnas = tablero->getColumnas();

    // Primer intento: Completar cualquier casilla si es posible (periferia)
    // Revisar primera y �ltima fila
    for (int j = 0; j < columnas - 1; ++j) {
        if (juego->esMovimientoValido(0, j, 0, j + 1) &&
            juego->dejaCasillaDisponibleParaJugador(0, j, 0, j + 1) &&
            juego->hacerMovimiento(0, j, 0, j + 1)) {
            return;
        }
        if (juego->esMovimientoValido(filas - 1, j, filas - 1, j + 1) &&
            juego->dejaCasillaDisponibleParaJugador(filas - 1, j, filas - 1, j + 1) &&
            juego->hacerMovimiento(filas - 1, j, filas - 1, j + 1)) {
            return;
        }
    }

    // Revisar primera y �ltima columna
    for (int i = 0; i < filas - 1; ++i) {
        if (juego->esMovimientoValido(i, 0, i + 1, 0) &&
            juego->dejaCasillaDisponibleParaJugador(i, 0, i + 1, 0) &&
            juego->hacerMovimiento(i, 0, i + 1, 0)) {
            return;
        }
        if (juego->esMovimientoValido(i, columnas - 1, i + 1, columnas - 1) &&
            juego->dejaCasillaDisponibleParaJugador(i, columnas - 1, i + 1, columnas - 1) &&
            juego->hacerMovimiento(i, columnas - 1, i + 1, columnas - 1)) {
            return;
        }
    }

    // Segundo intento: Movimientos seguros (periferia)
    // Revisar primera y �ltima fila
    for (int j = 0; j < columnas - 1; ++j) {
        if (juego->esMovimientoValido(0, j, 0, j + 1) &&
            !juego->dejaCasillaDisponibleParaOponente(0, j, 0, j + 1) &&
            juego->hacerMovimiento(0, j, 0, j + 1)) {
            return;
        }
        if (juego->esMovimientoValido(filas - 1, j, filas - 1, j + 1) &&
            !juego->dejaCasillaDisponibleParaOponente(filas - 1, j, filas - 1, j + 1) &&
            juego->hacerMovimiento(filas - 1, j, filas - 1, j + 1)) {
            return;
        }
    }

    // Revisar primera y �ltima columna
    for (int i = 0; i < filas - 1; ++i) {
        if (juego->esMovimientoValido(i, 0, i + 1, 0) &&
            !juego->dejaCasillaDisponibleParaOponente(i, 0, i + 1, 0) &&
            juego->hacerMovimiento(i, 0, i + 1, 0)) {
            return;
        }
        if (juego->esMovimientoValido(i, columnas - 1, i + 1, columnas - 1) &&
            !juego->dejaCasillaDisponibleParaOponente(i, columnas - 1, i + 1, columnas - 1) &&
            juego->hacerMovimiento(i, columnas - 1, i + 1, columnas - 1)) {
            return;
        }
    }

    // Tercer intento: Movimiento aleatorio seguro
    EstrategiaAleatoria* aleatoria = new EstrategiaAleatoria();
    aleatoria->realizarMovimiento(juego);
}
