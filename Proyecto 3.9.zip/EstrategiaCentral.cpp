#include "EstrategiaCentral.h"

void EstrategiaCentral::realizarMovimiento(Juego* juego) {
    Tablero* tablero = juego->obtenerTablero();
    int filas = tablero->getFilas();
    int columnas = tablero->getColumnas();
    int centroFila = filas / 2;
    int centroColumna = columnas / 2;

    // Primer intento: Completar cualquier casilla si es posible
    for (int i = -1; i <= 1; ++i) {
        for (int j = -1; j <= 1; ++j) {
            if (juego->esMovimientoValido(centroFila + i, centroColumna + j, centroFila + i + 1, centroColumna + j) &&
                juego->dejaCasillaDisponibleParaJugador(centroFila + i, centroColumna + j, centroFila + i + 1, centroColumna + j)) {
                if (juego->hacerMovimiento(centroFila + i, centroColumna + j, centroFila + i + 1, centroColumna + j)){
                    return;
                }
            }
            if (juego->esMovimientoValido(centroFila + i, centroColumna + j, centroFila + i, centroColumna + j + 1) &&
                juego->dejaCasillaDisponibleParaJugador(centroFila + i, centroColumna + j, centroFila + i, centroColumna + j + 1)){
                if (juego->hacerMovimiento(centroFila + i, centroColumna + j, centroFila + i, centroColumna + j + 1)){
                    return;
                }
            }
        }
    }

    // Segundo intento: Movimientos seguros
    for (int i = -1; i <= 1; ++i) {
        for (int j = -1; j <= 1; ++j) {
            if (juego->esMovimientoValido(centroFila + i, centroColumna + j, centroFila + i + 1, centroColumna + j) &&
                !juego->dejaCasillaDisponibleParaOponente(centroFila + i, centroColumna + j, centroFila + i + 1, centroColumna + j)){
                if (juego->hacerMovimiento(centroFila + i, centroColumna + j, centroFila + i + 1, centroColumna + j)){
                    return;
                }
            }
            if (juego->esMovimientoValido(centroFila + i, centroColumna + j, centroFila + i, centroColumna + j + 1) &&
                !juego->dejaCasillaDisponibleParaOponente(centroFila + i, centroColumna + j, centroFila + i, centroColumna + j + 1)){
                if (juego->hacerMovimiento(centroFila + i, centroColumna + j, centroFila + i, centroColumna + j + 1)){
                    return;
                }
                
            }
        }
    }

    // Tercer intento: Movimiento aleatorio seguro
    EstrategiaAleatoria* aleatorio = new EstrategiaAleatoria();
    aleatorio->realizarMovimiento(juego);
}


