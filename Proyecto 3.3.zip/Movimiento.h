#pragma once

class Movimiento {
public:
    int x1, y1, x2, y2;
    Movimiento(int x1, int y1, int x2, int y2);
};
