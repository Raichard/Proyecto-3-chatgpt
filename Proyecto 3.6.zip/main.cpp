#include "Juego.h"
#include "Jugador.h"
#include "EstrategiaAleatoria.h"
#include "EstrategiaCercana.h"
#include "EstrategiaPeriferica.h"
#include "EstrategiaCentral.h"
#include "EstrategiaIslas.h"

int main() {
    Jugador jugador1(1, "Richi", true);
    Jugador jugador2(2, "Yuben", true);
    int fil = 5;
    int col = 5;

    // Definir un �rea irregular din�micamente
    bool** area = new bool* [fil];
    for (int i = 0; i < fil; ++i) {
        area[i] = new bool[col];
        for (int j = 0; j < col; j++) {
            area[i][j] = true;
        }
    }

    Juego* game = new Juego(fil, col, &jugador1, &jugador2, area);

    Estrategia* estrategia = new EstrategiaAleatoria(); // Ejemplo inicial
    game->cambiarEstrategia(estrategia);

    while (!game->esFinDelJuego()) {
        std::cout << game->obtenerTablero()->mostrar() << std::endl;

        std::cout << "Ultimo movimiento P1: " << jugador1.obtenerUltimaJugada().x1 << jugador1.obtenerUltimaJugada().y1 << jugador1.obtenerUltimaJugada().x2 << jugador1.obtenerUltimaJugada().y2 << std::endl;
        std::cout << "Ultimo movimiento IA: " << jugador2.obtenerUltimaJugada().x1 << jugador2.obtenerUltimaJugada().y1 << jugador2.obtenerUltimaJugada().x2 << jugador2.obtenerUltimaJugada().y2 << std::endl;

        if (game->obtenerJugadorActual() == &jugador1) {
            int x1, y1, x2, y2;
            std::cout << "Turno de " << game->obtenerJugadorActual()->getNombre() << "\n";
            std::cout << "Ingrese las coordenadas (x1 y1 x2 y2): ";
            std::cin >> x1 >> y1 >> x2 >> y2;

            if (!game->hacerMovimiento(x1, y1, x2, y2)) {
                std::cout << "Movimiento inv�lido. Intente de nuevo.\n";
            }
        }
        else {
            std::cout << "Toca IA" << std::endl;
            game->realizarMovimientoAI();

            cout << "Prueba de (1, 2) -> (1, 3)" << endl;
            cout << game->dejaCasillaDisponibleParaOponente(1, 2, 1, 3) << endl;
            cout << "Verificando movimiento (2, 0) -> (2, 1):" << endl;
            cout << game->dejaCasillaDisponibleParaOponente(2, 0, 2, 1) << endl;
        }
    }

    std::cout << game->obtenerTablero()->mostrar() << std::endl;
    Jugador* ganador = game->determinarGanador();
    if (ganador) {
        std::cout << "El ganador es " << ganador->getNombre() << " con " << ganador->getPuntuacionActual() << " puntos!\n";
    }
    else {
        std::cout << "El juego termin� en empate.\n";
    }

    // Liberar memoria del �rea
    for (int i = 0; i < fil; ++i) {
        delete[] area[i];
    }
    delete[] area;

    delete game;

    return 0;
}

//encontrar la forma de revisar como verificaria el siguiente caso ya que tiro un error de acceso:
//no se encontro casilla ganada al: 400 intento
// Verificando movimiento(1, 2) -> (1, 3) :
