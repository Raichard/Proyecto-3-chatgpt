#include "EstrategiaIslas.h"

void EstrategiaIslas::realizarMovimiento(Juego* juego) {
    Tablero* tablero = juego->obtenerTablero();
    int filas = tablero->getFilas();
    int columnas = tablero->getColumnas();

    // Primer intento: Completar cualquier casilla si es posible
    for (int i = 1; i < filas - 1; ++i) {
        for (int j = 1; j < columnas - 1; ++j) {
            if (juego->esMovimientoValido(i, j, i + 1, j) &&
                juego->dejaCasillaDisponibleParaJugador(i, j, i + 1, j) &&
                juego->hacerMovimiento(i, j, i + 1, j)) {
                return;
            }
            if (juego->esMovimientoValido(i, j, i, j + 1) &&
                juego->dejaCasillaDisponibleParaJugador(i, j, i, j + 1) &&
                juego->hacerMovimiento(i, j, i, j + 1)) {
                return;
            }
        }
    }

    // Segundo intento: Movimientos seguros
    for (int i = 1; i < filas - 1; ++i) {
        for (int j = 1; j < columnas - 1; ++j) {
            if (juego->esMovimientoValido(i, j, i + 1, j) &&
                !juego->dejaCasillaDisponibleParaOponente(i, j, i + 1, j) &&
                juego->hacerMovimiento(i, j, i + 1, j)) {
                return;
            }
            if (juego->esMovimientoValido(i, j, i, j + 1) &&
                !juego->dejaCasillaDisponibleParaOponente(i, j, i, j + 1) &&
                juego->hacerMovimiento(i, j, i, j + 1)) {
                return;
            }
        }
    }

    // Tercer intento: Movimiento aleatorio seguro
    EstrategiaAleatoria* aleatorio = new EstrategiaAleatoria();
    aleatorio->realizarMovimiento(juego);
}

