#include "EstrategiaPeriferica.h"

void EstrategiaPeriferica::realizarMovimiento(Juego* juego) {
    Tablero* tablero = juego->obtenerTablero();
    int filas = tablero->getFilas();
    int columnas = tablero->getColumnas();

    // Primer intento: Completar cualquier casilla si es posible
    for (int i = 0; i < filas; ++i) {
        if (juego->esMovimientoValido(i, 0, i, 1) &&
            juego->dejaCasillaDisponibleParaJugador(i, 0, i, 1) &&
            juego->hacerMovimiento(i, 0, i, 1)) {
            return;
        }
        if (juego->esMovimientoValido(i, columnas - 1, i, columnas - 2) &&
            juego->dejaCasillaDisponibleParaJugador(i, columnas - 1, i, columnas - 2) &&
            juego->hacerMovimiento(i, columnas - 1, i, columnas - 2)) {
            return;
        }
    }

    for (int j = 0; j < columnas; ++j) {
        if (juego->esMovimientoValido(0, j, 1, j) &&
            juego->dejaCasillaDisponibleParaJugador(0, j, 1, j) &&
            juego->hacerMovimiento(0, j, 1, j)) {
            return;
        }
        if (juego->esMovimientoValido(filas - 1, j, filas - 2, j) &&
            juego->dejaCasillaDisponibleParaJugador(filas - 1, j, filas - 2, j) &&
            juego->hacerMovimiento(filas - 1, j, filas - 2, j)) {
            return;
        }
    }

    // Segundo intento: Movimientos seguros
    for (int i = 0; i < filas; ++i) {
        if (juego->esMovimientoValido(i, 0, i, 1) &&
            !juego->dejaCasillaDisponibleParaOponente(i, 0, i, 1) &&
            juego->hacerMovimiento(i, 0, i, 1)) {
            return;
        }
        if (juego->esMovimientoValido(i, columnas - 1, i, columnas - 2) &&
            !juego->dejaCasillaDisponibleParaOponente(i, columnas - 1, i, columnas - 2) &&
            juego->hacerMovimiento(i, columnas - 1, i, columnas - 2)) {
            return;
        }
    }

    for (int j = 0; j < columnas; ++j) {
        if (juego->esMovimientoValido(0, j, 1, j) &&
            !juego->dejaCasillaDisponibleParaOponente(0, j, 1, j) &&
            juego->hacerMovimiento(0, j, 1, j)) {
            return;
        }
        if (juego->esMovimientoValido(filas - 1, j, filas - 2, j) &&
            !juego->dejaCasillaDisponibleParaOponente(filas - 1, j, filas - 2, j) &&
            juego->hacerMovimiento(filas - 1, j, filas - 2, j)) {
            return;
        }
    }

    // Tercer intento: Movimiento aleatorio seguro
    EstrategiaAleatoria* aleatoria = new EstrategiaAleatoria();
    aleatoria->realizarMovimiento(juego);
}

