#include "EstrategiaPeriferica.h"

void EstrategiaPeriferica::realizarMovimiento(Juego* juego) {
    Tablero* tablero = juego->obtenerTablero();
    int filas = tablero->getFilas();
    int columnas = tablero->getColumnas();

    // Implementar l�gica para colocar l�neas en los bordes del �rea de juego

    while (true) {
        for (int i = 0; i < filas; ++i) {
            if (juego->hacerMovimiento(i, 0, i, 1) || juego->hacerMovimiento(i, columnas - 1, i, columnas - 2)) {
                return;
            }
        }
        for (int j = 0; j < columnas; ++j) {
            if (juego->hacerMovimiento(0, j, 1, j) || juego->hacerMovimiento(filas - 1, j, filas - 2, j)) {
                return;
            }
        }
    }
}
