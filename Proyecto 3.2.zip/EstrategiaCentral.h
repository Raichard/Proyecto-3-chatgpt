#pragma once

#include "Estrategia.h"

class EstrategiaCentral : public Estrategia {
public:
    void realizarMovimiento(Juego* juego) override;
};
