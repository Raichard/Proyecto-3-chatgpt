#pragma once

#include "Estrategia.h"

class EstrategiaPeriferica : public Estrategia {
public:
    void realizarMovimiento(Juego* juego) override;
};
