#include "EstrategiaIslas.h"

void EstrategiaIslas::realizarMovimiento(Juego* juego) {
    Tablero* tablero = juego->obtenerTablero();
    int filas = tablero->getFilas();
    int columnas = tablero->getColumnas();

    // Implementar l�gica para completar peque�as "islas" o �reas de tama�o reducido

    while (true) {
        for (int i = 0; i < filas - 1; ++i) {
            for (int j = 0; j < columnas - 1; ++j) {
                if (juego->hacerMovimiento(i, j, i, j + 1) || juego->hacerMovimiento(i, j, i + 1, j)) {
                    return;
                }
            }
        }
    }
}
