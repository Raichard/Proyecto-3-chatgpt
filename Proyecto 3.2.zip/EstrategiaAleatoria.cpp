#include "EstrategiaAleatoria.h"

EstrategiaAleatoria::EstrategiaAleatoria() {
    srand(time(NULL)); // Inicializar la semilla para n�meros aleatorios
}

void EstrategiaAleatoria::realizarMovimiento(Juego* juego) {
    Tablero* tablero = juego->obtenerTablero();
    int filas = tablero->getFilas();
    int columnas = tablero->getColumnas();

    while (true) {
        int x1 = rand() % (filas - 1);
        int y1 = rand() % (columnas - 1);

        // Generar un movimiento aleatorio en una direcci�n v�lida
        int dir = rand() % 4;
        int x2 = x1, y2 = y1;

        switch (dir) {
        case 0: // Arriba
            x2 = x1 - 1;
            break;
        case 1: // Abajo
            x2 = x1 + 1;
            break;
        case 2: // Izquierda
            y2 = y1 - 1;
            break;
        case 3: // Derecha
            y2 = y1 + 1;
            break;
        }

        // Verificar que las coordenadas est�n dentro de los l�mites del tablero
        if (x2 >= 0 && x2 < filas && y2 >= 0 && y2 < columnas) {
            if (juego->hacerMovimiento(x1, y1, x2, y2)) {
                break;
            }
        }
    }
}

void EstrategiaAleatoria::realizarMovimientoAleatorioSeguro(Juego* juego) {
    realizarMovimiento(juego);
}
