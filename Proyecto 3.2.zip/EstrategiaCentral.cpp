#include "EstrategiaCentral.h"

void EstrategiaCentral::realizarMovimiento(Juego* juego) {
    Tablero* tablero = juego->obtenerTablero();
    int filas = tablero->getFilas();
    int columnas = tablero->getColumnas();
    int centroX = filas / 2;
    int centroY = columnas / 2;

    // Implementar l�gica para colocar l�neas desde el centro del �rea de juego
    for (int i = centroX - 1; i <= centroX; ++i) {
        for (int j = centroY - 1; j <= centroY; ++j) {
            if (juego->hacerMovimiento(i, j, i + 1, j) || juego->hacerMovimiento(i, j, i, j + 1)) {
                return;
            }
        }
    }
}
