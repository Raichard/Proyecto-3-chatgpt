#pragma once

#include "Estrategia.h"

class EstrategiaIslas : public Estrategia {
public:
    void realizarMovimiento(Juego* juego) override;
};